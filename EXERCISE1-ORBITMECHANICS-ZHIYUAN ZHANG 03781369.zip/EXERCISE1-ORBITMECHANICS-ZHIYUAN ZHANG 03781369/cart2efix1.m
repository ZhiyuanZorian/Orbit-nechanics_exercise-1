function [pos_efix, vel_efix] = cart2efix(pos_space, vel_space, t, theta_s)
% Transform the position and velocity in a spacefixed system
% into position and velocity in an Earth-fixed system
%
% Inputs:
%   pos_space   - position in the spacefixed system [m]
%   vel_space   - velocity in the spacefixed system [m/s]
%   t           - current time [h]
%   theta_s     - initial sidereal time [h]

% Constants
Omega_earth = 2 * pi / 86164; % Earth's rotation rate in rad/s
sidereal_start = theta_s*3600; % Initial sidereal time at t0

% Current sidereal time in seconds from t0 (Nov. 06, 2023, 00:00 UT)
% Assuming 'time' is in seconds from t0
sidereal_time = -Omega_earth * (t*3600+ sidereal_start);

% Rotation matrix for z-axis rotation
R = [cos(sidereal_time) -sin(sidereal_time) 0;
    sin(sidereal_time)  cos(sidereal_time) 0;
    0                   0                   1];

% Transform position
pos_efix = R * pos_space;

% Transform velocity
% The velocity transformation includes the rotational velocity of the Earth
% Rotational velocity component. Velocity's Cross Product with Earth's Rotation Axis
vel_rot = Omega_earth * [-pos_space(2); pos_space(1); 0]; 
vel_efix = R * vel_space + vel_rot;
end
