%% create a serie of struct to store data
clear all; close all;
GM=398600500000000;
eps=0.0000001;
%S(1)=GOCE
s(1).a=6629000; s(1).e=0.004; s(1).i=96.6/(2*pi); s(1).o=210/(2*pi);
s(1).w=144/(2*pi);s(1).T0=1;
%s(2)=GPS
s(2).a=26560000; s(2).e=0.01; s(2).i=55/(2*pi); s(2).o=30/(2*pi);
s(2).w=30/(2*pi);s(2).T0=11;
%s(3)=Molniya
s(3).a=26554000; s(3).e=0.7; s(3).i=63/(2*pi); s(3).o=200/(2*pi);
s(3).w=270/(2*pi);s(3).T0=5;
%s(4)=GEO
s(4).a=42164000; s(4).e=0; s(4).i=0/(2*pi); s(4).o=0/(2*pi);
s(4).w=50/(2*pi);s(4).T0=0;
%s(5)=Michibiki
s(5).a=42164000; s(5).e=0.075; s(5).i=41/(2*pi); s(5).o=200/(2*pi);
s(5).w=270/(2*pi);s(5).T0=19;
%% Task1: orbits in 2D plane
t=100; %t as the input
for j=1:5
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).interval=t-s(j).T0;          %calculate time interval
    s(j).M=s(j).n*s(j).interval*3600; %When calculate M, the unit of time interval should be s
    s(j).matrix=zeros(7,s(j).interval*60); %value matrix for satellites
    number=s(j).interval*60;  % When going through t, I choose i, the interval between i and i+1 is 60s (1min)
    ecc=s(j).e;  
    for i=1:number
       s(j).matrix(1,i)=i*60;  %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       s(j).matrix(2,i)=mod(s(j).matrix(2,i),2*pi);
      % M=s(j).matrix(2,i);
      % if M>=360
       %    M=M-360;
       %end
       %s(j).matrix(2,i)=M;
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(3,i)=mod(s(j).matrix(3,i),2*pi);
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       %s(j).matrix(5,i)=2*atan2(sqrt(1+ecc)*tan(E/2),sqrt(1-ecc));
       v_temporal=s(j).matrix(5,i);
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
       if(v_temporal<0)
           s(j).matrix(5,i)=s(j).matrix(5,i)+2*pi;  
       end
       s(j).matrix(5,i)=s(j).matrix(5,i)*180/pi;
       s(j).matrix(3,i)=s(j).matrix(3,i)*180/pi;
       s(j).matrix(2,i)=s(j).matrix(2,i)*180/pi;
    end
    
end


%% Result presentation
%combine
GOCEx=s(1).matrix(6,:);GOCEy=s(1).matrix(7,:);GPSx=s(2).matrix(6,:);GPSy=s(2).matrix(7,:);Molniyax=s(3).matrix(6,:);Molniyay=s(3).matrix(7,:);
GEOx=s(4).matrix(6,:);GEOy=s(4).matrix(7,:);Michibikix=s(5).matrix(6,:);Michibikiy=s(5).matrix(7,:);
figure(1)
plot(GOCEx,GOCEy,GPSx,GPSy,Molniyax,Molniyay,GEOx,GEOy,Michibikix,Michibikiy,'-.')
legend('GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('x[m]')
ylabel('y[m]')
xlim([-50000000 50000000]);
ylim([-50000000 50000000]);
axis equal
title('Combining 5 orbits of satellites in 2D plane')
%time parameters
figure(2)
%s(1).matrix=s(1).matrix(:,1:400);
plot(s(1).matrix(1,:),s(1).matrix(2,:),s(1).matrix(1,:),s(1).matrix(3,:),s(1).matrix(1,:),s(1).matrix(5,:),s(1).matrix(1,:),s(1).matrix(5,:)-s(1).matrix(2,:))
legend('M','E','V','V-M')
xlim([0 47500]);
xlabel('time[s]')
ylim([-50 380]);
ylabel('angle[degree]')
title('Angle parameters of GOCE')
figure(3)
%s(2).matrix=s(2).matrix(:,1:700);
plot(s(2).matrix(1,:),s(2).matrix(2,:),s(2).matrix(1,:),s(2).matrix(3,:),s(2).matrix(1,:),s(2).matrix(5,:),s(2).matrix(1,:),s(2).matrix(5,:)-s(2).matrix(2,:))
legend('M','E','V','V-M')
xlim([0 47500]);
xlabel('time[s]')
ylim([-50 380]);
ylabel('angle[degree]')
title('Angle parameters of GPS')
figure(4)
%s(3).matrix=s(3).matrix(:,1:400);
%plot(s(2).matrix(1,:),s(2).matrix(2,:),s(2).matrix(1,:),s(2).matrix(3,:),s(2).matrix(1,:),s(2).matrix(5,:),s(2).matrix(1,:),s(2).matrix(5,:)-s(2).matrix(3,:))
plot(s(3).matrix(1,:),s(3).matrix(2,:),s(3).matrix(1,:),s(3).matrix(3,:),s(3).matrix(1,:),s(3).matrix(5,:),s(3).matrix(1,:),s(3).matrix(5,:)-s(3).matrix(2,:))
ylim([-100 400]);
xlim([0 47500]);
legend('M','E','V','V-M')
xlabel('time[s]')
ylabel('angle[degree]')
title('Angle parameters of Molnyia')
figure(5)
%s(4).matrix=s(4).matrix(:,1:400);
plot(s(4).matrix(1,:),s(4).matrix(2,:),s(4).matrix(1,:),s(4).matrix(3,:),s(4).matrix(1,:),s(4).matrix(5,:),s(4).matrix(1,:),s(4).matrix(5,:)-s(4).matrix(2,:))
legend('M','E','V','V-M')
%xlim([0 47500]);
xlabel('time[s]')
ylim([-50 380]);
ylabel('angle[degree]')
title('Angle parameters of GEO')
figure(6)
%s(5).matrix=s(5).matrix(:,1:2000);
plot(s(5).matrix(1,:),s(5).matrix(2,:),s(5).matrix(1,:),s(5).matrix(3,:),s(5).matrix(1,:),s(5).matrix(5,:),s(5).matrix(1,:),s(5).matrix(5,:)-s(5).matrix(2,:))
legend('M','E','V','V-M')
%xlim([0 47500]);
xlabel('time[s]')
ylim([-50 380]);
ylabel('angle[degree]')
title('Angle parameters of Michibiki')
