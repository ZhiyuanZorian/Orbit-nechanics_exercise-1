function [latitude, longitude, height] = xyzblh(x, y, z)
    % WGS84椭球参数
    a = 6378137.0; % 长半轴
    f = 1 / 298.257223563; % 扁率

    % 计算椭球的短半轴
    b = a * (1 - f);

    % 计算第一偏心率的平方
    e_squared = (a^2 - b^2) / a^2;

    % 计算经度
    longitude = atan2(y, x);

    % 计算纬度
    rho = sqrt(x^2 + y^2);
    tan_phi = z / (rho * (1 - e_squared));
    latitude = atan2(z + e_squared * b * (sin(tan_phi))^3, rho - a * e_squared * (cos(tan_phi))^3);

    % 计算大地高
    sin_phi = sin(latitude);
    N = a / sqrt(1 - e_squared * sin_phi^2);
    height = rho / cos(latitude) - N;
end
