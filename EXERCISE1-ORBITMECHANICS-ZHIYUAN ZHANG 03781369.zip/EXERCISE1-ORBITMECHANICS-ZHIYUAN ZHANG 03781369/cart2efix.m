%% create a serie of struct to store data
clear all; close all;
GM=398600500000000;
eps=0.00001;
omegaE=2*pi/86164;
siderealtime=3*60*60;
%siderealtime=2*pi*(3*60*60)/(24*3600);
%S(1)=GOCE
s(1).a=6629000; s(1).e=0.004; s(1).i=96.6*2*pi/360; s(1).o=210*2*pi/360;
s(1).w=144*2*pi/360;s(1).T0=1;
%s(2)=GPS
s(2).a=26560000; s(2).e=0.01; s(2).i=55*2*pi/360; s(2).o=30*2*pi/360;
s(2).w=30*2*pi/360;s(2).T0=11;
%s(3)=Molniya
s(3).a=26554000; s(3).e=0.7; s(3).i=63*2*pi/360; s(3).o=200*2*pi/360;
s(3).w=270*2*pi/360;s(3).T0=5;
%s(4)=GEO
s(4).a=42164000; s(4).e=0; s(4).i=0*2*pi/360; s(4).o=0*2*pi/360;
s(4).w=50*2*pi/360;s(4).T0=0;
%s(5)=Michibiki
s(5).a=42164000; s(5).e=0.075; s(5).i=41*2*pi/360; s(5).o=200*2*pi/360;
s(5).w=270*2*pi/360;s(5).T0=19;
%% Task1: orbits in 2D plane
t=60; %t as the input
for j=1:5
    if j==1
        t=6;
    else
        t=65;
    end
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).interval=t-s(j).T0;    % the interval calculated in hours
    number=s(j).interval*60;
    s(j).M=s(j).n*s(j).interval*3600; %unit of interval should be s
    s(j).matrix=zeros(7,number); %value matrix for satellites
    s(j).rmatrix=zeros(3,number); % rmatrix to describe vector r
    s(j).theta0=zeros(1,number);
    %s(j).r3matrix=zeros(3,s(j).interval*60);
    s(j).latiandlongti=zeros(2,number);
    s(j).rdotmatrix=zeros(3,number); %rdotmatrix to describe vector rdot
    ecc=s(j).e;
    i0=s(j).i*(-1); o0=s(j).o*(-1); w0=s(j).w*(-1);
    s(j).imatrix=[1,0,0;0,cos(i0),sin(i0);0,(-1)*sin(i0),cos(i0)];   %R1(-i)
    s(j).omatrix=[cos(o0),sin(o0),0;(-1)*sin(o0),cos(o0),0;0,0,1];   %R3(-o)
    s(j).wmatrix=[cos(w0),sin(w0),0;(-1)*sin(w0),cos(w0),0;0,0,1];   %R3(-w) 
    for i=1:number
       s(j).matrix(1,i)=i*60;  %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       v_temporal=s(j).matrix(5,i);
       s(j).rmatrix(1,i)=r_temporal*cos(v_temporal);           %vector r line 1
       s(j).rmatrix(2,i)=r_temporal*sin(v_temporal);           %vector r line 2
       s(j).rdotmatrix(1,i)=r_temporal*sin(v_temporal)*(-1);           %vector rdot line 1
       s(j).rdotmatrix(2,i)=r_temporal*(cos(v_temporal)+ecc);            %vector rdot line 2
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
       s(j).r_equator(:,i)=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix(:,i);
       s(j).theta0(1,i)=omegaE*(i*60+s(j).T0*3600)+2*pi/8;   %theta0
       theta=s(j).theta0(1,i);
       thetamatrix=[cos(theta),sin(theta),0;(-1)*sin(theta),cos(theta),0;0,0,1];  %R3(theta0)
       s(j).r3matrix(:,i)=thetamatrix*s(j).r_equator(:,i);    %r3=R3(theta0(t))*r2
       x3=s(j).r3matrix(1,i);y3=s(j).r3matrix(2,i);z3=s(j).r3matrix(3,i);  %the vector of r3
       s(j).latiandlongti(1,i)=360*atan2(y3,x3)/(2*pi); %longitude
       s(j).latiandlongti(2,i)=360*atan(z3/sqrt(x3*x3+y3*y3))/(2*pi); %laditude
    end
    s(j).rdotmatrix = s(j).rdotmatrix*sqrt(GM/(s(j).a*(1-ecc*ecc)));
    s(j).r_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix;       %position
    s(j).rdot_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rdotmatrix; %velocity 
    %resultr3(j).matrix=s(j).r3matrix;
end

%% Result presentation
figure (1)
axis equal
Earth_coast(3)
h11=plot3(s(1).r3matrix(1,:)',s(1).r3matrix(2,:)',s(1).r3matrix(3,:)','b.','Linewidth', 1);
h12=plot3(s(2).r3matrix(1,:)',s(2).r3matrix(2,:)',s(2).r3matrix(3,:)','Linewidth', 1);
h13=plot3(s(3).r3matrix(1,:)',s(3).r3matrix(2,:)',s(3).r3matrix(3,:)','Linewidth', 1);
h14=plot3(s(4).r3matrix(1,:)',s(4).r3matrix(2,:)',s(4).r3matrix(3,:)','r*','Linewidth', 1);
h15=plot3(s(5).r3matrix(1,:)',s(5).r3matrix(2,:)',s(5).r3matrix(3,:)','Linewidth', 1);
legend([h11,h12,h13,h14,h15],'GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('x[m]')
ylabel('y[m]')
zlabel('z[m]')
title('Combining 5 orbits in earth fixed system')

figure 
axis equal
Earth_coast(2)
hold on;
h1=plot(s(1).latiandlongti(1,:)',s(1).latiandlongti(2,:)','b.-');
hold on;
h2=plot(s(2).latiandlongti(1,:)',s(2).latiandlongti(2,:)');
hold on;
h3=plot(s(3).latiandlongti(1,:)',s(3).latiandlongti(2,:)');
hold on;
h4=plot(s(4).latiandlongti(1,:)',s(4).latiandlongti(2,:)','r*');
hold on;
h5=plot(s(5).latiandlongti(1,:)',s(5).latiandlongti(2,:)');
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('longtitude[degree]')
ylabel('latitude[degree]')
title('Ground track of 5 sateltiles')
