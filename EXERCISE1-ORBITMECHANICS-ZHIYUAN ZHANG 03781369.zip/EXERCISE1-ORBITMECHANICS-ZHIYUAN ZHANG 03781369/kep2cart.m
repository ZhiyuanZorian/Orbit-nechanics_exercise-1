%% create a serie of struct to store data
clear all; close all;
GM=398600500000000;
eps=0.00000001;
%S(1)=GOCE
s(1).a=6629000; s(1).e=0.004; s(1).i=96.6*2*pi/360; s(1).o=210*2*pi/360;
s(1).w=144*2*pi/360;s(1).T0=1;
%s(2)=GPS
s(2).a=26560000; s(2).e=0.01; s(2).i=55*2*pi/360; s(2).o=30*2*pi/360;
s(2).w=30*2*pi/360;s(2).T0=11;
%s(3)=Molniya
s(3).a=26554000; s(3).e=0.7; s(3).i=63*2*pi/360; s(3).o=200*2*pi/360;
s(3).w=270*2*pi/360;s(3).T0=5;
%s(4)=GEO
s(4).a=42164000; s(4).e=0; s(4).i=0*2*pi/360; s(4).o=0*2*pi/360;
s(4).w=50*2*pi/360;s(4).T0=0;
%s(5)=Michibiki
s(5).a=42164000; s(5).e=0.075; s(5).i=41*2*pi/360; s(5).o=200*2*pi/360;
s(5).w=270*2*pi/360;s(5).T0=19;
%% Task1: orbits in 2D plane
t=88; %t as the input
for j=1:5
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).interval=t-s(j).T0;
    s(j).M=s(j).n*s(j).interval*3600; %unit of interval should be s
    s(j).matrix=zeros(7,s(j).interval*60); %value matrix for satellites
    s(j).rmatrix=zeros(3,s(j).interval*60); % rmatrix to describe vector r
    s(j).rdotmatrix=zeros(3,s(j).interval*60); %rdotmatrix to describe vector rdot
    number=s(j).interval*60;
    ecc=s(j).e;
    i0=s(j).i*(-1); o0=s(j).o*(-1); w0=s(j).w*(-1);
    s(j).imatrix=[1,0,0;0,cos(i0),sin(i0);0,(-1)*sin(i0),cos(i0)];   %R1(-i)
    s(j).omatrix=[cos(o0),sin(o0),0;(-1)*sin(o0),cos(o0),0;0,0,1];   %R3(-o)
    s(j).wmatrix=[cos(w0),sin(w0),0;(-1)*sin(w0),cos(w0),0;0,0,1];   %R3(-w) 
    for i=1:number
       s(j).matrix(1,i)=i*60;  %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       v_temporal=s(j).matrix(5,i);
       s(j).rmatrix(1,i)=r_temporal*cos(v_temporal);           %vector r line 1
       s(j).rmatrix(2,i)=r_temporal*sin(v_temporal);           %vector r line 2
       s(j).rdotmatrix(1,i)=sin(v_temporal)*(-1);           %vector rdot line 1
       s(j).rdotmatrix(2,i)=cos(v_temporal)+ecc;            %vector rdot line 2
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
    end
    s(j).rdotmatrix = s(j).rdotmatrix*sqrt(GM/(s(j).a*(1-ecc*ecc)));
    s(j).r_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix;       %position
    s(j).rdot_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rdotmatrix; %velocity
    s(j).velocity_magnitude=s(j).rdot_equator.*s(j).rdot_equator;
    %s(j).velocity_magnitude(4,:)=s(j).velocity_magnitude(1,:)+s(j).velocity_magnitude(2,:)+s(j).velocity_magnitude(3,:);
    %s(j).velocity_magnitude(4,:)=sqrt(s(j).velocity_magnitude(4,:));
    s(j).velocity_magnitude(4,:) = sqrt(s(j).velocity_magnitude(1,:).^2 + s(j).velocity_magnitude(2,:).^2 + s(j).velocity_magnitude(3,:).^2);
    %sum=sqrt(sum);
    s(j).velocity_magnitude(4,:)=sqrt(s(j).velocity_magnitude(4,:));
    s(j).velocity_magnitude(1,:)=sqrt(s(j).rdotmatrix(1,:).^2+s(j).rdotmatrix(2,:).^2);
    s(j).velocity_magnitude(4,:)=s(j).velocity_magnitude(1,:);
    x=s(j).r_equator(1,:)';
    y=s(j).r_equator(2,:)';
    z=s(j).r_equator(3,:)';
end

%% Result presentation
figure(6)
Earth_coast(3)
%plot3(s(1).r_equator(1,:)',s(1).r_equator(2,:)',s(1).r_equator(3,:)',s(2).r_equator(1,:)',s(2).r_equator(2,:)',s(2).r_equator(3,:)',s(3).r_equator(1,:)',s(3).r_equator(2,:)',s(3).r_equator(3,:)',s(4).r_equator(1,:)',s(4).r_equator(2,:)',s(4).r_equator(3,:)',s(5).r_equator(1,:)',s(5).r_equator(2,:)',s(5).r_equator(3,:)')
h1=plot3(s(1).r_equator(1,:)',s(1).r_equator(2,:)',s(1).r_equator(3,:)');
h2=plot3(s(2).r_equator(1,:)',s(2).r_equator(2,:)',s(2).r_equator(3,:)');
h3=plot3(s(3).r_equator(1,:)',s(3).r_equator(2,:)',s(3).r_equator(3,:)');
h4=plot3(s(4).r_equator(1,:)',s(4).r_equator(2,:)',s(4).r_equator(3,:)');
h5=plot3(s(5).r_equator(1,:)',s(5).r_equator(2,:)',s(5).r_equator(3,:)');
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
%gocex=s(1).r_equator(1,:)';gocey=s(1).r_equator(2,:)';gocez=s(1).r_equator(3,:)';
%gpsx=s(2).r_equator(1,:)';gpsy=s(2).r_equator(2,:)';gpsz=s(2).r_equator(3,:)';
%plot3(gocex,gocey,gocez,gpsx,gpsy,gpsz)
%axis equal
xlabel('x[m]')
ylabel('y[m]')
zlabel('z[m]')
title('Combining 5 orbits of satellites in 3D plane')
figure(7)
axis equal
hold on;
h1=plot(s(1).r_equator(1,:)',s(1).r_equator(3,:)');
hold on;
h2=plot(s(2).r_equator(1,:)',s(2).r_equator(3,:)');
hold on;
h3=plot(s(3).r_equator(1,:)',s(3).r_equator(3,:)');
hold on;
h4=plot(s(4).r_equator(1,:)',s(4).r_equator(3,:)');
hold on;
h5=plot(s(5).r_equator(1,:)',s(5).r_equator(3,:)');
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('x[m]')
xlim([-50000000 50000000])
ylabel('z[m]')
ylim([-50000000 50000000])
title('Space fixed system: XZ plane')
figure(8)
axis equal
hold on;
h1=plot(s(1).r_equator(1,:)',s(1).r_equator(2,:)');
hold on;
h2=plot(s(2).r_equator(1,:)',s(2).r_equator(2,:)');
hold on;
h3=plot(s(3).r_equator(1,:)',s(3).r_equator(2,:)');
hold on;
h4=plot(s(4).r_equator(1,:)',s(4).r_equator(2,:)');
hold on;
h5=plot(s(5).r_equator(1,:)',s(5).r_equator(2,:)');
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('x[m]')
xlim([-50000000 50000000])
ylabel('y[m]')
ylim([-50000000 50000000])
title('Space fixed system: XY plane')
figure(9)
axis equal
hold on;
h1=plot(s(1).r_equator(2,:)',s(1).r_equator(3,:)');
hold on;
h2=plot(s(2).r_equator(2,:)',s(2).r_equator(3,:)');
hold on;
h3=plot(s(3).r_equator(2,:)',s(3).r_equator(3,:)');
hold on;
h4=plot(s(4).r_equator(2,:)',s(4).r_equator(3,:)');
hold on;
h5=plot(s(5).r_equator(2,:)',s(5).r_equator(3,:)');
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
xlabel('y[m]')
xlim([-50000000 50000000])
ylabel('z[m]')
ylim([-50000000 50000000])
title('Space fixed system: YZ plane')
figure(11)
hold on;
h1=plot(s(1).matrix(1,:), s(1).velocity_magnitude(4,:));
hold on;
h2=plot(s(2).matrix(1,:), s(2).velocity_magnitude(4,:));
hold on;
h3=plot(s(3).matrix(1,:), s(3).velocity_magnitude(4,:));
hold on;
h4=plot(s(4).matrix(1,:), s(4).velocity_magnitude(4,:));
hold on;
h5=plot(s(5).matrix(1,:), s(5).velocity_magnitude(4,:));
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
xlim([0 100000])
xlabel('Time [s]')
ylabel('Velocity Magnitude [m/s]')
title('Velocity Magnitude over Time')
